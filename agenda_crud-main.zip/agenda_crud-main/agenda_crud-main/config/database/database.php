<?php
    $con = new mysqli("127.0.0.1","root", "root", "Guilherme") or die("Error: " . mysqli_connect_error());
?>
